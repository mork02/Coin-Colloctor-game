    def draw_coin(self):
        for coin_rect, rand_x in self.coin_list:
            screen.blit(pygame.image.load('png/gold.png'), (rand_x, coin_rect.y - 30))
            coin_rect.y += 2