import pygame, sys, random


class player_rect:
    def __init__(self):
        self.wall = 'left'
        self.x = 100

        self.sprites_left = []
        self.sprites_left.append(pygame.image.load('png/p1_L.png'))
        self.sprites_left.append(pygame.image.load('png/p2_L.png'))
        self.sprites_left.append(pygame.image.load('png/p3_L.png'))
        self.sprites_left.append(pygame.image.load('png/p4_L.png'))
        self.sprites_left.append(pygame.image.load('png/p5_L.png'))
        self.sprites_left.append(pygame.image.load('png/p4_L.png'))
        self.sprites_left.append(pygame.image.load('png/p3_L.png'))
        self.sprites_left.append(pygame.image.load('png/p2_L.png'))
        self.sprites_left.append(pygame.image.load('png/p1_L.png'))
        self.sprites_right = []
        self.sprites_right.append(pygame.image.load('png/p1_R.png'))
        self.sprites_right.append(pygame.image.load('png/p2_R.png'))
        self.sprites_right.append(pygame.image.load('png/p3_R.png'))
        self.sprites_right.append(pygame.image.load('png/p4_R.png'))
        self.sprites_right.append(pygame.image.load('png/p5_R.png'))
        self.sprites_right.append(pygame.image.load('png/p4_R.png'))
        self.sprites_right.append(pygame.image.load('png/p3_R.png'))
        self.sprites_right.append(pygame.image.load('png/p2_R.png'))
        self.sprites_right.append(pygame.image.load('png/p1_R.png'))

        self.current_sprite = 0
        if self.wall == 'left':
            self.image = self.sprites_left[self.current_sprite]
        elif self.wall == 'right':
            self.image = self.sprites_right[self.current_sprite]

        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = width / 2 - 50, height - 200

        self.active_img = False

        self.start = False
        self.game_over = False
        self.game_over_button = pygame.Rect(310, 450, 375, 100)

        self.coin_inv = 0
        self.hp = 5

        self.player_velocity = 0
        self.gravity = .5

    def add_image(self):
        if self.active_img:
            if self.wall == 'left':
                screen.blit(self.sprites_left[int(self.current_sprite)], (self.rect.x, self.rect.y))
                self.current_sprite += .25
                if self.current_sprite >= len(self.sprites_left):
                    self.current_sprite = 0
                    self.active_img = False
            elif self.wall == 'right':
                screen.blit(self.sprites_right[int(self.current_sprite)], (self.rect.x, self.rect.y))
                self.current_sprite += .25
                if self.current_sprite >= len(self.sprites_right):
                    self.current_sprite = 0
                    self.active_img = False
        else:
            if self.wall == 'left':
                screen.blit(self.sprites_left[0], (self.rect.x, self.rect.y))
            elif self.wall == 'right':
                screen.blit(self.sprites_right[0], (self.rect.x, self.rect.y))

    def jump(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE]:
            self.player_velocity = -10
            self.start = True
            self.active_img = True
        if self.start:
            self.rect.y += self.player_velocity
            self.player_velocity += self.gravity

    def check_gameover(self):
        if self.hp <= 0:
            self.game_over = True

    def game_over_screen(self):
        if self.game_over:
            font_lose = pygame.font.Font(None, 100)
            text_lose = font_lose.render('YOU LOST!', False, 'RED')
            font_gold = pygame.font.Font(None, 82)
            text_gold = font_gold.render(f'COLLECTED {self.coin_inv} Coins!', False, 'YELLOW')
            font_close = pygame.font.Font(None, 52)
            text_close = font_close.render(f'CLICK TO CLOSE!', False, 'black')
            pygame.draw.rect(screen, (30,30,30), (200, 200, 600, 400))
            screen.blit(text_lose, (310, 250))
            screen.blit(text_gold, (210, 350))
            pygame.draw.rect(screen, 'red', self.game_over_button)
            screen.blit(text_close, (345, 475))

    def moving(self):
        if self.start:
            if self.wall == 'left':
                self.rect.x -= 5
            elif self.wall == 'right':
                self.rect.x += 5
        if self.rect.y <= -50:
            self.rect.y = -50

        if self.rect.y >= 900:
            self.start = False
            self.hp -= 1
            coin_.coin_list.clear()
            self.rect.y = height - 200
            self.rect.x = width / 2 - 50

    def draw(self):
        font = pygame.font.Font(None, 52)
        show_coin = font.render(f'Coins: {self.coin_inv}', False, 'Yellow')
        screen.blit(show_coin, (30, 0))

        for i in range(self.hp):
            x = i * (50 + 20) + 20 + 600
            pygame.draw.rect(screen, 'red', (x, 10, 30 , 30))

    def update(self):
        self.check_gameover()
        self.draw()
        self.add_image()
        self.jump()
        self.moving()
        coin_.collect_coin()

class Walls:
    def __init__(self):
        self.wall_rect_left = pygame.Rect(0, -50, 25, height + 50)
        self.wall_rect_right = pygame.Rect(width - 25, -50, 25, height + 50)

    def draw(self):
        pygame.draw.rect(screen, 'green', self.wall_rect_left)
        pygame.draw.rect(screen, 'green', self.wall_rect_right)

    def collide_with_wall(self):
        if player_.rect.colliderect(self.wall_rect_left):
            player_.wall = 'right'
        elif player_.rect.colliderect(self.wall_rect_right):
            player_.wall = 'left'

    def update(self):
        self.draw()
        self.collide_with_wall()

class Background:
    def __init__(self):
        self.bg_list = []
        self.spawn_block_x, self.spawn_block_y = player_.rect.x, player_.rect.y
        self.moving = False

    def add_bg(self):
        ran_x = random.randint(25, width - 125)
        ran_y = random.randint(25, height - 125)
        rect = pygame.Surface((100, 100), pygame.SRCALPHA)
        rect.fill((0, 130, 255, 5))
        self.bg_list.append([rect, ran_x, ran_y, random.choice([3, -3]), random.choice([5, -5])])

    def move_background(self):
        remove_indices = []
        for i, bg in enumerate(self.bg_list):
            rect, ran_x, ran_y, dx, dy = bg
            bg[1] += dx
            bg[2] += dy

            if bg[1] >= width + 100 or bg[1] <= 0 - 100 or bg[2] >= height + 100 or bg[2] <= 0 - 100:
                remove_indices.append(i)

        for index in reversed(remove_indices):
            del self.bg_list[index]

    def draw_bg(self):
        for bg in self.bg_list:
            rect, ran_x, ran_y = bg[:3]
            screen.blit(rect, (ran_x, ran_y))

    def draw_spawn_block(self):
        if not player_.start:
            self.spawn_block_x, self.spawn_block_y = player_.rect.x, player_.rect.y
            self.moving = False
        elif player_.start:
            self.moving = True
            if self.moving:
                self.spawn_block_y += 1
                if self.spawn_block_y >= width + 25:
                    self.moving = False
        pygame.draw.rect(screen, 'white', (self.spawn_block_x - 15, self.spawn_block_y + 50, 80, 20))


    def update(self):
        self.add_bg()
        self.move_background()
        self.draw_bg()
        if not player_.game_over:
            self.draw_spawn_block()

class Coin:
    def __init__(self):
        self.timer = 0

        self.coin_list = []

    def add_coin(self):
        self.timer += 1
        if len(self.coin_list) <= 4:
            if self.timer >= 120:
                rand_x = random.randint(0, width)
                coin = pygame.Rect(rand_x, -30, 25, 25)
                self.coin_list.append(coin)
                self.timer = 0

    def collision_wts(self):
        try:
            for i in range(len(self.coin_list)):
                for j in range(i + 1, len(self.coin_list)):
                    if self.coin_list[i].colliderect(self.coin_list[j]):
                        self.coin_list.remove(self.coin_list[j])
        except Exception as e:
            print(e)
        for i in range(len(self.coin_list)):
            try:
                if self.coin_list[i].colliderect(wall_.wall_rect_left) or self.coin_list[i].colliderect(wall_.wall_rect_right):
                    self.coin_list.remove(self.coin_list[i])
            except Exception as e:
                print(e)
        for i in range(len(self.coin_list)):
            try:
                if self.coin_list[i].y >= 850:
                    player_.hp -= 1
                    self.coin_list.remove(self.coin_list[i])
            except Exception as e:
                print(e)

    def collect_coin(self):
        for i in range(len(self.coin_list)):
            try:
                if self.coin_list[i].colliderect(player_.rect):
                    self.coin_list.remove(self.coin_list[i])
                    player_.coin_inv += 1
            except Exception as e:
                print(e)

    def draw_coin(self):
        for coin in self.coin_list:
            pygame.draw.rect(screen, 'yellow', coin)
            coin.y += 2

    def update(self):
        if player_.start:
            self.add_coin()
            self.draw_coin()
            self.collision_wts()

pygame.init()

width, height = 1000, 800
screen = pygame.display.set_mode((width, height))

clock = pygame.time.Clock()
fps = 30

player_ = player_rect()
wall_ = Walls()
coin_ = Coin()
bg = Background()

game = True
while game:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game = False
            sys.exit()

    mx, my = pygame.mouse.get_pos()
    screen.fill((0,0,0))
    bg.update()
    if not player_.game_over:
        wall_.update()

        coin_.update()

        player_.update()
    else:
        player_.game_over_screen()
        if player_.game_over_button.collidepoint(mx, my):
            if event.type == pygame.MOUSEBUTTONDOWN:
                game = False
                sys.exit()

    pygame.display.flip()
    clock.tick(60)